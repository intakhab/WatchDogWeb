package com.hcl.dog.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Paths;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.hcl.dog.common.WatchDogException;
import com.hcl.dog.component.DataLoaderComponent;
import com.hcl.dog.domain.PlanId;
import com.hcl.dog.domain.PlanIds;
import com.hcl.dog.domain.SOPlan;
import com.hcl.dog.domain.SoSystemPlanId;
import com.hcl.dog.dto.PlanDescriptionDto;
import com.hcl.dog.dto.ResponseDto;
/**
 * 
 * @author intakhabalam.s@hcl.com
 * @see {@link Service}
 *
 */
@Service
public class PlanIDService {
	
	private Logger logger = LogManager.getLogger("planid-serv");
	@Autowired
	private CommonService commonService;
	@Autowired
	private XMLUtilService xmlUtilService;
	@Autowired
	private Environment env;
   
    @Autowired
	private DataLoaderComponent dataLoader;
    private final String  FIND_ENTITIES_NAME="getEntity@so.xml";
    private final String FIND_ENTITES_API_NAME = "getEntity";
	PlanDescriptionDto planDesDto=PlanDescriptionDto.getInstance();

	
	/***
	 * This method will check the plan id from SO file. 
	 * Check into db if it does exist then not save otherwise save
	 * @param inputFile  {@link File}
	 * @throws WatchDogException {@link WatchDogException}
	 */
	public void modifyInputApiXML4PlanId(File inputFile) throws WatchDogException {
		planDesDto.reset();
		String planId = xmlUtilService.getValueFromXML(inputFile, commonService.TNS_SYSTEM_PLAN_ID);
		if(planId==null) {
			planId = xmlUtilService.getValueFromXML(inputFile, commonService.SYSTEM_PLAN_ID);
		}
		if(planId==null) {
			logger.error("PlanId not found in this file => "+inputFile.getName());
			return;
		}
		logger.info("PlanId found [ "+planId+" ]  for file => "+inputFile.getName());
		//Before Saving PlanId, I need to get the description of plan id
		 boolean b=callPlanDescription(planId);
		 if(!b) {
			  logger.info("PlanId will not go for auto optimization call");
			  return;
		 }
		try {
			PlanIds planIds = xmlUtilService.
					convertXMLToObject(PlanIds.class, Paths.get(env.getProperty("db.planid")).toFile());
			if(planIds!=null ) {
				List<PlanId> planList = planIds.getPlanId();
				boolean isFound=false;
				if(planList!=null && planList.size()>0) {
					
					for (PlanId p : planList) {
						// Here saving the plan id input file name and condition
						if (planId.trim().equals(p.getId().trim())) {
							logger.info("PlanId already exist in DB {} ");
							isFound=true;
							break;
						}
					}
				}
				if(!isFound) {
					commonService.storeSystemId(planId, planDesDto, "0");//not found in list so inserting into DB. 0 shows inserting first time
				}
			}else {
				commonService.storeSystemId(planId, planDesDto,"0");  // Assuming plansIds is null so inserting into DB
			}
			
		} catch (FileNotFoundException | JAXBException e) {
			logger.error("Error: {PlanIds-0001}  {modifyInputApiXML4PlanId} " + e.getMessage());
		}
		
	}
	
	/***
	 * @param planId
	 * @return {@link Boolean}
	 */
	public boolean callPlanDescription(String planId) {
		File findEntityFile=Paths.get(dataLoader.configDto.getSoOrderInputFolderPath()
				+File.separator+FIND_ENTITIES_NAME).toFile();
		try {
		   boolean isModified=xmlUtilService.modifyValuesInXML(findEntityFile, "Id", planId);
		   if(isModified) {
			  logger.info("Find Entity xml put with plan id::"+planId);
			  return invokeBatchResponse(findEntityFile,FIND_ENTITES_API_NAME);
		   }
		}catch (Exception e) {
            logger.error("Error {PlanIds-0002} :  {readSystemPlanIds} " + e.getMessage());
		}
		return false;
	}
	
	
	/***
	 * 
	 * @param inputFile {@link File}
	 * @param apiName {@link String}
	 * @return as boolean {@link Boolean}
	 * @throws WatchDogException {@link WatchDogException}
	 */
	private boolean invokeBatchResponse(File apiInputFile,
			String apiName) throws WatchDogException {
		
         boolean success=false;
         String [] commandArgs= prepareCommandArgs(apiInputFile, apiName);
         String filePath=apiInputFile.getPath();
            	
		ResponseDto responseDto = commonService.
				runCommandLineBatch(dataLoader.configDto.getBatchFilePath(),commandArgs[0],filePath);
		
		if (responseDto.isCommandRun()) {
			logger.info("PlanIDs findEntities Batch Run Successfully...");
			if (checkPlanIdResponseCode(apiInputFile,apiName,commandArgs[1])) {
				logger.info("PlanIDs findEntities API completed sucessfully [ " + filePath + " ] ");
				success= true;

			}
		}
	
		return success;
	}
	
	/***
	 * This method will check the response xml 
	 * in specific location which sending by TMS
	 * @param inputFile {@link File}
	 * @param apiName {@link String}
	 * @param responeFile {@link String}
	 * @return boolean {@link Boolean}
	 * @throws WatchDogException {@link WatchDogException}
	 */
	private boolean checkPlanIdResponseCode(File apiInputFile,String apiName,
			String responeFile) throws WatchDogException {

		logger.info("PlanIDs Scanning Response XML in directory  [ " + dataLoader.configDto.getOutputFolderPath() + " ]");
		if (!commonService.checkFile(responeFile)) {
			logger.error("PlanIDs { :: "+commonService.RESPONSE_NOT_FOUND_FROM_TMS+" :: } ===>  for file [ " + responeFile + " ]");
			return false;
		}

		logger.info("PlanIDs { :: "+commonService.RESPONSE_FOUND_FROM_TMS+" :: } ===>  for file [ " + responeFile + " ]");
		boolean b=false;
		try {
			File resFile = Paths.get(responeFile).toFile();
			String responseTagVal = xmlUtilService.getValueFromXML(resFile,
					dataLoader.configDto.getResponeCodeTag());
			// Print XML
			xmlUtilService.printXML(resFile);
			if (commonService.TRUE_STR.equalsIgnoreCase(responseTagVal)) {
				b=readSystemPlanIds(responeFile);
			} 
		} catch (Exception e) {
			throw new WatchDogException("Error {PlanIDs-0003} :   {checkResponseCode} " + e.getMessage());
		}
		return b;
        
	}
	
	
	/**
	 * 
	 * @param inputFile
	 * @param responeFile
	 * @param name
	 * @param fbPay
	 * @return boolean
	 */
	private boolean readSystemPlanIds(String responeFile) {

		try {
			SoSystemPlanId sysPlanIds=(SoSystemPlanId)	xmlUtilService
					.convertXMLToObject(SoSystemPlanId.class,Paths.get(responeFile).toFile());
			SOPlan  soPlan=sysPlanIds.getEntity().getPlan();
			if(soPlan!=null) {
				
				logger.info("SystemPlanID :: "+soPlan.getSystemPlanID());
				logger.info("PlanDescription :: "+soPlan.getPlanDescription());
				logger.info("LogisticsGroupCode :: "+soPlan.getLogisticsGroupCode());
				logger.info("DivisionCode :: "+soPlan.getDivisionCode());
				//
				String desc=soPlan.getPlanDescription().toLowerCase().trim();
				
				if(desc.startsWith("auto")) {
					planDesDto.isReadAuto=true;
					planDesDto.divisionCode=soPlan.getDivisionCode();
					planDesDto.logisticsGroupCode=soPlan.getLogisticsGroupCode();
					planDesDto.systemPlanID=soPlan.getSystemPlanID();
					planDesDto.planDescription=soPlan.getPlanDescription();
					return true;
				}
			}
			
		} catch (Exception e) {
            logger.error("Error {PlanId-0004} :  {readSystemPlanIds} " + e.getMessage());
            
		}

		return false;
	}
	
	/***
	 * This will prepare command which will invoke with command line
	 * @param inputFile {@link File}
	 * @param apiName {@link String}
	 * @return String array
	 */

	private String[]  prepareCommandArgs(File inputFile, String apiName) {
        String fileName=inputFile.getName();
		String [] out_with_Args=new String[2];
		String inputFolderFileName = dataLoader.configDto.getSoOrderInputFolderPath() + File.separator + fileName;
		
		String outPutFolder = dataLoader.configDto.getOutputFolderPath() 
				+ File.separator 
				+ dataLoader.configDto.getResponseFilePrefix()
				+ FilenameUtils.getBaseName(fileName)
				+ commonService.UNDERSCORE_STR
				+ commonService.currentTime()
				+ commonService.DOT_STR
				+ dataLoader.configDto.getFileExtension();

		StringBuilder sb = new StringBuilder(apiName)
				.append(commonService.AND_STR)
				.append(inputFolderFileName)
				.append(commonService.AND_STR)
				.append(outPutFolder);
		
		out_with_Args[0]=sb.toString();
		out_with_Args[1]=outPutFolder;

		return out_with_Args;
	}
}
