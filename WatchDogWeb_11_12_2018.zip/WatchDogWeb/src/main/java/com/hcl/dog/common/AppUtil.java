package com.hcl.dog.common;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import com.hcl.dog.dto.MailDto;
/***
 * 
 * @author intakhabalam.s@hcl.com
 * @see {@link MailDto}
 */
public class AppUtil {

	
	public static final String COMMA_SEPERATOR = ",";
	public static final String EMPTY_STR = "";
	public static final String WHITE_SPACE = "\\s";
    public static final String DOT_STR="\\.";
	public static final String WATCH_DOG_GREET_MSG = "\\\\/\\/atch[|)og";
	public static final String FILE_SEPARTOR = "@";

	/***
	 * @param listOfItems {@link List}
	 * @param separator {@link String}
	 * @return {@link String}
	 */
	public static String concatenate(List<String> listOfItems, String separator) {
		StringBuilder sb = new StringBuilder();
		Iterator<String> stit = listOfItems.iterator();

		while (stit.hasNext()) {
			sb.append(stit.next());
			if (stit.hasNext()) {
				sb.append(separator);
			}
		}

		return sb.toString();
	}
	
	
	
	/***
	 * @param apiString
	 * @return {@link String}
	 */
	public static String checkAndRemoveCurlyStr(String apiString) {
		
		if (apiString.contains("{") || apiString.contains("}")) {
			apiString = apiString.replaceAll("\\{", AppUtil.EMPTY_STR).replaceAll("\\}", AppUtil.EMPTY_STR);
		}
		return apiString;
	}
	/**
	 * Checks if is collection empty.
	 * @param collection {@link Collection}
	 * @return {@link Boolean}
	 */
	private static boolean isCollectionEmpty(Collection<?> collection) {
		if (collection == null || collection.isEmpty()) {
			return true;
		}
		return false;
	}
	
	/**
	 * Checks if is object empty.
	 * @param object {@link Object}
	 * @return {@link Boolean}
	 */
	public static boolean isObjectEmpty(Object object) {
		if(object == null) return true;
		else if(object instanceof String) {
			if (((String)object).trim().length() == 0) {
				return true;
			}
		} else if(object instanceof Collection) {
			return isCollectionEmpty((Collection<?>)object);
		}
		return false;
	}
}
